//
// Created for Art Generator
// by Stewart Lynch on 2022-11-20
// Using Swift 5.0
//
// Follow me on Twitter: @StewartLynch
// Subscribe on YouTube: https://youTube.com/StewartLynch
//

import SwiftUI

@main
struct AppEntry: App {
    var body: some Scene {
        WindowGroup {
            DALLEImagesView()
        }
    }
}
